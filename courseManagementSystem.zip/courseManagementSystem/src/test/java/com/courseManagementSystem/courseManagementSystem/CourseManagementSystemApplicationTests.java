package com.courseManagementSystem.courseManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
